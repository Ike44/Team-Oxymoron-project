# Team-Oxymoron-project

# Condition

### Team Members:
* Designer - Mico Masangkay
* Producer - Isaac Amanor
* Programmer - Walter Nguyen

### Game controls:
* WASD - Movement
* E - Interaction

